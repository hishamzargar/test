import numpy as np
import os
from matplotlib import pyplot as plt
import cv2
import random
import pickle

#Path of the data. My folder name is data and I am working in the same directory
directory = "data"

#Different characters of the language
classes = ["Aen", "Alif", "Baa", "BadiYe", "Chay", "ChotiYe", "Daal","D'aal",
	       "Day", "DoChae", "Fay","Gaaf", "Ghen", "Hae","Hamza","Hey",
           "Jeem", "Kaaf","Kha","Laam","Meem","Noon","Pay","Qaaf","Re", "Say",
           "Seen","Sheen","Suad","Tauy","Tay","T'ay", "Wao","Zaal","Zay","Zhae",
           "Zuad","Zuay"]


# The size of the images
image_size = 28

# All images are checked in the data folder one by one using x variable
for x in classes :
	path = os.path.join(directory, x)
	for image in os.listdir(path):
		arr_of_img = cv2.imread(os.path.join(path, image), cv2.IMREAD_GRAYSCALE)

training_data = []

def create_training_data():
    for x in classes :
        path = os.path.join(directory, x)
        each_class = classes.index(x)
        for image in os.listdir(path):
            arr_of_img = cv2.imread(os.path.join(path, image), cv2.IMREAD_GRAYSCALE)
            np_array = cv2.resize(arr_of_img, (image_size, image_size))
            training_data.append([np_array, each_class])


create_training_data()                       #function call
random.shuffle(training_data)

X = [] #features
y = [] #labels

for features, label in training_data:
	X.append(features)
	y.append(label)

X = np.array(X).reshape(-1, image_size, image_size, 1)   #reshaping the numpy array

# Dumping out the array data in .pickle file
file_out = open("X.pickle", "wb")
pickle.dump(X, file_out)
file_out.close()

file_out = open("y.pickle", "wb")
pickle.dump(y, file_out)
file_out.close()

file_in = open("X.pickle", "rb")
X = pickle.load(file_in)
